"""Driver: run the N-S seed-and-propagate build-out on a tx sample and emit
results/RESULTS-ns-propagation.md. `run_on_signatures` is the offline-testable core;
`run` wires the real ancestry/entities/combiner modules. Summary includes whole-partition
bits (entropy over the full label partition) before vs. after merge propagation."""
from decluster.propagate import (NSPropagator, holdout_reid,
                                 partition_from_assignment)
from decluster.graph_metric import partition_entropy
from decluster.combiner import Combiner


def _partition_bits(assigned):
    """Entropy (bits) of the WHOLE label partition at once — the uncertainty about which
    cluster a random node falls in. `partition_entropy` of a single group is 0 by
    construction, so this must be computed over all groups together, NOT per-group."""
    return partition_entropy(partition_from_assignment(assigned))


def run_on_signatures(node_sigs, seed_labels, node_txs, rarity, combiner=None,
                      theta=0.5, min_score=0.1, refuse_below=-2.0, cospend_clusters=None):
    """Offline core: given precomputed signatures, run both channels and summarise.
    `before` = the seed labeling; `after` = the merge-propagated labeling. `refined` counts
    the split channel's output groups over the supplied co-spend clusters (empty if none)."""
    class _Agree:
        def score(self, a, b): return 3.0
    combiner = combiner or _Agree()
    prop = NSPropagator(rarity, combiner, theta=theta, min_score=min_score,
                        refuse_below=refuse_below)
    before = seed_labels
    after = prop.propagate(node_sigs, seed_labels)
    reid = holdout_reid(node_sigs, seed_labels, prop)
    refined = prop.refine(cospend_clusters or [], node_sigs, node_txs)
    return {"partition_bits_before": _partition_bits(before),
            "partition_bits_after": _partition_bits(after),
            "reid_rate": reid["rate"], "n_nodes": len(node_sigs),
            "n_refined_groups": len(refined)}


def run(txs, seeds, depth=6):
    """Real wiring: build per-node provenance signatures and rarity, then summarise.
    `txs` maps node -> representative tx dict; `seeds` maps node -> label.

    The link oracle is named rather than inherited: the walk's default moved to nominal value flow,
    and RESULTS-ns-propagation.md reports the subset-sum walk (its cache harness pins the same
    oracle explicitly).
    """
    from decluster.ancestry import ancestry_signature, dss_link_oracle
    from decluster.propagate import build_rarity, entity_signature
    node_sigs = {}
    for node, tx in txs.items():
        coin = (tx["txid"], 0)
        node_sigs[node] = entity_signature(
            [ancestry_signature(coin, depth=depth, link_oracle=dss_link_oracle)])
    rarity = build_rarity(node_sigs.values())
    node_txs = {node: tx for node, tx in txs.items()}
    return run_on_signatures(node_sigs, seeds, node_txs, rarity,
                             combiner=Combiner.from_library())
