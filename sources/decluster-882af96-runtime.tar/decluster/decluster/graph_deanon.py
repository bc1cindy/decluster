"""Narayanan-Shmatikov probe: does graph structure predict same-owner beyond co-spend?
Same-owner labels = transitive common-input clusters — a near-certain *heuristic*, not an independent same-owner oracle
(a collaborative tx in the slice would be a false merge). Held-out positives = same-owner pairs
NOT directly co-spent, scored by common neighbors. `evaluate` runs the 1-hop probe;
`analyze` sweeps graph depth k (hubs excluded) to show structure is deeper under churn.
usage: python3 -m decluster.graph_deanon [--depth] <slice.json...>

WHAT THIS ACTUALLY IMPLEMENTS. Common-neighbour link prediction on one graph, scored pairwise
(`structural_score` = |N(a) ∩ N(b)|). It has no seed set, no vertex correspondence, no propagation
and no second view — none of the four things the Narayanan--Shmatikov de-anonymization algorithm is
made of. The name records which paper motivated the probe, not which algorithm runs here. The
faithful reference implementation is `decluster/baselines/narayanan_shmatikov.py`, and
`decluster/baselines/link_prediction.py` is where a mapping from it actually drives link
prediction; this module's `structural_score` is that comparison's structure-only arm."""
import sys, random
from .measure import load_unique
from .unionfind import UF
from .change_gt import union_input_addrs

class CoSpent:
    """Membership test for "were these two addresses inputs to one transaction?", answered
    without materialising the pair set. A consolidation of n inputs implies n(n-1)/2 pairs,
    so the pair set is quadratic in the widest transaction: one 1059-input consolidation
    contributes ~560k pairs on its own, and a 144-block slice does not fit in memory.
    Storing address -> the transactions it funded is linear in inputs and answers the same
    question by set intersection. Supports `in` with a 2-element frozenset, so call sites
    read unchanged."""

    def __init__(self):
        self._txs = {}

    def add(self, key, addrs):
        """`key` identifies the transaction and must be unique per call; callers pass the
        sample index rather than the txid, which synthetic samples may not carry (keying on
        an absent txid collapses every transaction onto None and makes every pair co-spent)."""
        for a in addrs:
            self._txs.setdefault(a, set()).add(key)

    def __contains__(self, pair):
        it = iter(pair)
        a = next(it, None)
        b = next(it, a)                                  # a 1-element frozenset means a == b
        ta = self._txs.get(a)
        return bool(ta and ta & self._txs.get(b, frozenset()))


HUBCAP = 100      # don't expand through hubs (degree > this) — avoids small-world collapse
SIZECAP = 6000    # cap neighborhood growth


def build(sample, dust_guard=False):
    """neigh_pay excludes co-spend adjacency (which defines the same-owner labels) so the
    payment-only score is not circular. Returns (uf, neigh_full, neigh_pay, cospent).

    `dust_guard` (refuse-only): drop the counterparty edges a **dust fan-out** creates
    (`entities.detect_dust_fanout`) — a dusted address sharing the duster as a "counterparty" is the
    main confound for address-reuse/topology clustering (dust ≠ ownership), so those edges must not
    corroborate a merge. Co-spend is kept (it is not forgeable). No-op on value-less samples (the dust
    test needs output values, absent from the address-only BigQuery export)."""
    from .entities import detect_dust_fanout
    uf = UF()
    neigh_full, neigh_pay, cospent = {}, {}, CoSpent()
    for n, (tx, _) in enumerate(sample):
        union_input_addrs(tx, uf)                        # co-spend is a real, unforgeable signal — keep it
        if dust_guard and detect_dust_fanout(tx):
            continue                                     # dust spray: its output edges are not counterparty structure
        in_addr = [v.get("prevout", {}).get("scriptpubkey_address") for v in tx.get("vin", [])]
        in_addr = [a for a in in_addr if a]
        out_addr = [o.get("scriptpubkey_address") for o in tx.get("vout", []) if o.get("scriptpubkey_address")]
        cospent.add(n, in_addr)
        parts = set(in_addr) | set(out_addr)
        for a in parts:
            neigh_full.setdefault(a, set()).update(parts - {a})
        for a in in_addr:
            neigh_pay.setdefault(a, set()).update(out_addr)
        for o in out_addr:
            neigh_pay.setdefault(o, set()).update(in_addr)
    return uf, neigh_full, neigh_pay, cospent


def structural_score(a, b, neigh):
    """common neighbors (classic link prediction)."""
    return len(neigh.get(a, set()) & neigh.get(b, set()))


def auc(pos_scores, neg_scores, seed=0):
    """AUC = P(a positive pair scores above a negative pair), ESTIMATED by at most 20,000 sampled
    (positive, negative) draws with half credit for ties.

    This is a Monte-Carlo estimator, not the exact statistic: it is seeded and so reproducible, but
    two runs at different seeds differ in the third decimal, and every AUC published from this
    module and its callers (`fingerprint_validate`, `change_validate`, `fingerprint_ns`, `cluster`,
    `broadcast`) carries that sampling error. `exact_auc` below computes the same quantity exactly.
    They are not interchangeable at three decimals, so a number from one should not be compared
    against a number from the other without saying which produced it.

    Kept as the estimator because the repository's published AUCs were measured with it; new call
    sites should prefer `exact_auc`."""
    rng = random.Random(seed)
    if not pos_scores or not neg_scores: return None
    trials = min(20000, len(pos_scores) * len(neg_scores))
    wins = 0.0
    for _ in range(trials):
        p, n = rng.choice(pos_scores), rng.choice(neg_scores)
        wins += 1.0 if p > n else (0.5 if p == n else 0.0)
    return wins / trials


def exact_auc(scores, labels):
    """Exact Mann--Whitney AUC with half credit for ties: the rank-sum statistic, no sampling.

    Takes one score list with a parallel boolean-ish `labels` rather than two lists, because that
    is the shape an evaluation harness already holds. `None` when either class is empty, matching
    `auc`. O(n log n) — cheaper than `auc`'s 20,000 draws on any realistic n, and deterministic
    without a seed. The single implementation of the exact statistic in this repository;
    `fs_temporal._score_metrics` calls it."""
    positive = sum(1 for label in labels if label)
    negative = len(labels) - positive
    if not positive or not negative:
        return None
    ordered = sorted(zip(scores, labels), key=lambda item: item[0])
    rank_sum = 0.0
    index = 0
    while index < len(ordered):
        end = index + 1
        while end < len(ordered) and ordered[end][0] == ordered[index][0]:
            end += 1
        average_rank = ((index + 1) + end) / 2.0
        rank_sum += average_rank * sum(1 for _, label in ordered[index:end] if label)
        index = end
    statistic = rank_sum - positive * (positive + 1) / 2.0
    return statistic / (positive * negative)


def shuffle_auc(pos_scores, neg_scores, seed=0):
    """Shuffle-null control: randomly flip each aligned (pos, neg) pair's label, then AUC -> ~0.5."""
    rng = random.Random(seed)
    spos, sneg = [], []
    for p, ng in zip(pos_scores, neg_scores):
        if rng.random() < 0.5: spos.append(p); sneg.append(ng)
        else: spos.append(ng); sneg.append(p)
    return auc(spos, sneg, seed)


def _pairs(clusters, neigh, cospent, rng, cap=5000):
    """positives = same cluster but not directly co-spent (held-out); negatives = cross-cluster.

    The two classes are not degree-balanced, and the score reads degree. Positives are *every*
    intra-cluster pair, so they are quadratic in cluster size and dominated by the largest,
    highest-degree clusters; negatives are drawn uniformly over cluster *roots*, which gives a
    two-address cluster the same weight as a thousand-address one. `degree_matched_auc` is the
    control that says how much of the separation survives once that channel is closed."""
    pos, neg = [], []
    for members in clusters.values():
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                a, b = members[i], members[j]
                if frozenset((a, b)) in cospent: continue
                pos.append(structural_score(a, b, neigh))
    roots = list(clusters)
    for _ in range(cap):
        if len(roots) < 2: break
        r1, r2 = rng.sample(roots, 2)
        neg.append(structural_score(rng.choice(clusters[r1]), rng.choice(clusters[r2]), neigh))
    return pos, neg


def _degree_matched_negatives(clusters, neigh, positives, rng, tries=50):
    """One cross-cluster pair per positive, matching each endpoint's degree exactly.

    Endpoints are drawn from the addresses that share their positive counterpart's degree, so the
    negative class carries the positive class's degree distribution and a degree-only score sits
    at chance. A positive whose degree admits no cross-cluster partner is dropped, which is why
    the returned list can be shorter than `positives`."""
    root_of = {a: r for r, members in clusters.items() for a in members}
    by_degree = {}
    for a in root_of:
        by_degree.setdefault(len(neigh.get(a, ())), []).append(a)
    out = []
    for a, b in positives:
        left = by_degree.get(len(neigh.get(a, ())), ())
        right = by_degree.get(len(neigh.get(b, ())), ())
        if not left or not right:
            continue
        for _ in range(tries):
            x, y = rng.choice(left), rng.choice(right)
            if root_of[x] != root_of[y]:
                out.append((x, y))
                break
    return out


def degree_matched_auc(sample, seed=0):
    """`evaluate`'s AUCs recomputed against degree-matched negatives.

    `evaluate` publishes the numbers; this says how much of them is the degree asymmetry
    `_pairs` documents rather than shared structure. Reported alongside `degree_only_*`, the
    AUC of a score that is nothing but the pair's degree sum: at chance under this control by
    construction, and far from it under the published sampling."""
    uf, neigh_full, neigh_pay, cospent = build(sample)
    rng = random.Random(seed)
    out = {}
    for name, neigh in (("full", neigh_full), ("payment", neigh_pay)):
        clusters = _clusters(uf, neigh)
        pos = [(m[i], m[j]) for m in clusters.values()
               for i in range(len(m)) for j in range(i + 1, len(m))
               if frozenset((m[i], m[j])) not in cospent]
        neg = _degree_matched_negatives(clusters, neigh, pos, rng)
        labels = [True] * len(pos) + [False] * len(neg)
        pairs = pos + neg
        out[f"auc_{name}"] = exact_auc(
            [structural_score(a, b, neigh) for a, b in pairs], labels)
        out[f"degree_only_{name}"] = exact_auc(
            [len(neigh.get(a, ())) + len(neigh.get(b, ())) for a, b in pairs], labels)
        out[f"pos_pairs_{name}"], out[f"neg_pairs_{name}"] = len(pos), len(neg)
    return out


def _clusters(uf, neigh):
    clusters = {}
    for a in list(neigh):
        clusters.setdefault(uf.find(a), []).append(a)
    return {r: m for r, m in clusters.items() if len(m) >= 2}


def evaluate(sample, seed=0):
    uf, neigh_full, neigh_pay, cospent = build(sample)
    clusters = _clusters(uf, neigh_full)
    rng = random.Random(seed)
    pf, nf = _pairs(clusters, neigh_full, cospent, rng)
    pp, np_ = _pairs(clusters, neigh_pay, cospent, rng)
    alla = list(neigh_full)
    fake = {}
    for a in alla:
        fake.setdefault(rng.randrange(len(clusters) or 1), []).append(a)
    fake = {k: v for k, v in fake.items() if len(v) >= 2}
    ps, ns = _pairs(fake, neigh_full, set(), rng)   # shuffle control -> AUC ~0.5
    return {
        "addrs": len(alla), "clusters_ge2": len(clusters),
        "pos_pairs": len(pf), "neg_pairs": len(nf),
        "auc_full": auc(pf, nf, seed), "pos_mean_full": (sum(pf) / len(pf)) if pf else None,
        "auc_payment": auc(pp, np_, seed), "pos_mean_payment": (sum(pp) / len(pp)) if pp else None,
        "auc_shuffle": auc(ps, ns, seed),
    }


def _nk(x, pay, k, cache):
    if (x, k) in cache: return cache[(x, k)]
    seen = {x}; frontier = {x}
    for _ in range(k):
        nxt = set()
        for u in frontier:
            if u != x and len(pay.get(u, ())) > HUBCAP: continue
            nxt |= pay.get(u, set())
        frontier = nxt - seen; seen |= nxt
        if len(seen) > SIZECAP: break
    seen.discard(x); cache[(x, k)] = seen
    return seen


def analyze(sample, ks=(1, 2, 3, 4), cap=1500, seed=0):
    """Depth sweep: k-hop common neighbors (hubs excluded) vs held-out same-owner pairs."""
    uf, _full, pay, cospent = build(sample)
    clusters = _clusters(uf, pay)
    rng = random.Random(seed)
    allp = [(m[i], m[j]) for m in clusters.values()
            for i in range(len(m)) for j in range(i + 1, len(m))
            if frozenset((m[i], m[j])) not in cospent]
    if not allp:
        return {"entities": len(clusters), "pairs": 0, "share_pct": 0.0, "ks": ks, "aucs": [None] * len(ks)}
    pos = allp if len(allp) <= cap else rng.sample(allp, cap)
    roots = list(clusters)
    neg = [(rng.choice(clusters[a]), rng.choice(clusters[b]))
           for a, b in (rng.sample(roots, 2) for _ in range(cap))]
    share = 100 * sum(1 for a, b in pos if pay.get(a, set()) & pay.get(b, set())) / len(pos)
    cache, aucs = {}, []
    for k in ks:
        ps = [len(_nk(a, pay, k, cache) & _nk(b, pay, k, cache)) for a, b in pos]
        ns = [len(_nk(a, pay, k, cache) & _nk(b, pay, k, cache)) for a, b in neg]
        aucs.append(auc(ps, ns, seed))
    return {"entities": len(clusters), "pairs": len(allp), "share_pct": share, "ks": ks, "aucs": aucs}


def entity_label_uf(sample, labeler):
    """INDEPENDENT same-owner partition from an entity detector (disjoint from co-spend): every address
    a detector attributes to the same entity is unioned. `labeler(tx)` yields dicts with 'address' and
    'entity' (e.g. entities.detect_bitmex). This is the label the *strong* Narayanan-Shmatikov claim
    needs — it can group addresses co-spend leaves in separate clusters."""
    uf = UF()
    anchor, labeled = {}, set()                          # entity -> first address, to union the rest onto it
    for tx, _ in sample:
        for h in labeler(tx):
            a, e = h.get("address"), h.get("entity")
            if not a or not e:
                continue
            labeled.add(a)
            if e in anchor:
                uf.union(anchor[e], a)
            else:
                anchor[e] = a
    return uf, labeled


def evaluate_entity(sample, labeler, seed=0):
    """Strong N-S probe with an INDEPENDENT entity label: does payment-graph structure link same-entity
    addresses that co-spend leaves in separate clusters? Positives = same-entity pairs that are NOT
    directly co-spent; negatives = entity vs non-entity. Returns AUC on the payment-only graph, or None
    when the sample carries no multi-address entity (the usual case unless the slice covers an entity)."""
    _uf, _full, neigh_pay, cospent = build(sample)
    euf, labeled_all = entity_label_uf(sample, labeler)
    labeled = sorted(a for a in neigh_pay if a in labeled_all)
    clusters = {}
    for a in labeled:
        clusters.setdefault(euf.find(a), []).append(a)
    clusters = {r: m for r, m in clusters.items() if len(m) >= 2}
    for members in clusters.values():
        members.sort()
    rng = random.Random(seed)
    pos = [structural_score(m[i], m[j], neigh_pay)
           for m in clusters.values()
           for i in range(len(m)) for j in range(i + 1, len(m))
           if frozenset((m[i], m[j])) not in cospent]
    labeled_set = set(labeled)
    others = sorted(a for a in neigh_pay if a not in labeled_set)
    ent_addrs = list(labeled)
    neg = ([structural_score(rng.choice(ent_addrs), rng.choice(others), neigh_pay)
            for _ in range(min(5000, max(len(pos), 1)))] if ent_addrs and others else [])
    return {"entity_clusters": len(clusters), "pos_pairs": len(pos), "neg_pairs": len(neg),
            "auc_payment": auc(pos, neg, seed),
            "pos_mean": (sum(pos) / len(pos)) if pos else None}


def _load(paths):
    return load_unique(paths)


if __name__ == "__main__":
    if "--depth" in sys.argv:
        ks = (1, 2, 3, 4)
        print("%-14s %7s %8s %7s  %s" % ("slice", "entities", "pairs", "share%", "  ".join("k=%d" % k for k in ks)))
        for p in [a for a in sys.argv[1:] if a != "--depth"]:
            s = _load([p])
            heights = [int(tx.get("height", 0)) for tx, _ in s]
            r = analyze(s, ks=ks)
            print("blk %-10d %7d %8d %6.0f%%  %s" % (
                min(heights) if heights else 0, r["entities"], r["pairs"], r["share_pct"],
                "  ".join("%.2f" % a for a in r["aucs"])))
    else:
        sample = _load(sys.argv[1:])
        print(f"# {len(sample)} txs")
        r = evaluate(sample)
        print(f"addresses: {r['addrs']}  entities(>=2 addr): {r['clusters_ge2']}")
        print(f"held-out pairs (same-owner, transitive): {r['pos_pairs']}  negatives: {r['neg_pairs']}")
        print(f"AUC FULL     (co-spend+payment): {r['auc_full']:.4f}  pos_mean={r['pos_mean_full']:.2f}")
        print(f"AUC PAYMENT  (no co-spend, honest): {r['auc_payment']:.4f}  pos_mean={r['pos_mean_payment']:.2f}")
        print(f"AUC SHUFFLE  (control, ~0.5 expected): {r['auc_shuffle']:.4f}")
